﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PL.userControls
{
    /// <summary>
    /// Interaction logic for AnalyseBuyingUC.xaml
    /// </summary>
    public partial class AnalyseBuyingUC : UserControl
    {
        public event Action ShowButtonClickedEvent;
        public AnalyseBuyingUC()
        {
           
            InitializeComponent();
        }

        private void Show_Click(object sender, RoutedEventArgs e)
        {
            if (ShowButtonClickedEvent !=null)
            {
                ShowButtonClickedEvent();
            }


        }
    }
}
