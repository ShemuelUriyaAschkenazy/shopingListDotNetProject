﻿using BE;
using PL.commands;
using PL.commands.PL.commands;
using PL.models;
using PL.userControls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL;

namespace PL.viewModels
{
    public class AnalyseBuyingVM: IVM
    {
        BuyingModel Model;
        AnalyseBuyingUC AnalyseBuyingUC;
        public AnalyseBuyingVM(MainWindow main)
        {
            
            
            main.DataContext =this ;
            Model = new BuyingModel();
            buyinglist = new ObservableCollection<Buying>(Model.RecentBuyings);
            userlist = new ObservableCollection<User>(Model.userlist);
            storelist = new ObservableCollection<Store>(Model.storelist);
            productlist = new ObservableCollection<Product>(Model.productlist);
            categorylist = new ObservableCollection<Category>(Model.categorylist);
            AnalyseBuyingUC = main.centerOfPageGrid.GetChildOfType<AnalyseBuyingUC>();

            AnalyseBuyingUC.productsforselect.ItemsSource = productlist;



            AnalyseBuyingUC.ShowButtonClickedEvent += Active_ShowButtonClickedEvent;

        }

        private void Active_ShowButtonClickedEvent()
        {
            
            int count = 0;
            int check = 0;
            string Id=null ;
            string Id1=null;
            int j = productlist.Count;
            string product = AnalyseBuyingUC.productname.Text.ToString();
            string product1 = AnalyseBuyingUC.productname1.Text.ToString();
            for(int i=0;i<j;i++)
            {
                if (Model.productlist[i].ProductName.ToString()==product)
                {
                    Id = Model.productlist[i].ProductId.ToString();
                }
                if(Model.productlist[i].ProductName.ToString() == product1)
                {
                    Id1 = Model.productlist[i].ProductId.ToString();
                }
            }
              
            List<DateTime> datetime = new List<DateTime>();

           
             for(int i=0;i<Model.buyings.Count;i++)
            {
                if(!(datetime.Contains(Model.buyings[i].Date)))
                    {
                        datetime.Add(Model.buyings[i].Date);
                       
                    }
            }
            Buying A = null;
            Buying B = null;
            Buying C = null;
           for (int i = 0; i < Model.buyings.Count; i++)
            {
                if(Model.buyings[i].ProductId.ToString()== Id && check==0)
                {
                    A = Model.buyings[i];
                    Model.buyings[i].ProductId = -1;
                    check = 1;
                }
                if (Model.buyings[i].ProductId.ToString() == Id1)
                {
                    B = Model.buyings[i];
                }
                if(!(A==null)&& !(B==null))
                {
                    if (A.Date == B.Date)
                    {
                        count += 1;
                    }
                    
                }

            }
             float probability = count / datetime.Count();
            
             AnalyseBuyingUC.probability.Text = probability.ToString();
             

        }
    }
}
